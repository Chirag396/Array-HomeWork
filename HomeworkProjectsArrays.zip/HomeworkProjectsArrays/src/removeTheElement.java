import java.util.Arrays;

public class removeTheElement {

    public static void main(String[] args)
    {

        // Get the array
        int[] arr = { 1, 2, 3, 4, 5 };

        // Print the resultant array
        System.out.println("Original Array: " + Arrays.toString(arr));

        // Get the specific index
        int index = 2;

        // Print the index
        System.out.println("Index to be removed: " + index);

        // Remove the element

        // Print the resultant array
        System.out.println("Resultant Array: "
                + Arrays.toString(arr));
    }
}





